<?php 
class Association extends Conducteur && extends Vehicule
{
    private $id;
    public function __construct($id)
    {

    }
}


?>